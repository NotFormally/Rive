# 🚀 Smart Prep List — Déploiement du Cron automatique

## Résumé
Deux fichiers à mettre à jour dans ton repo + une variable d'environnement à ajouter sur Vercel.

---

## Étape 1 — Remplacer `vercel.json` (racine du repo)

Copie le fichier `vercel.json` fourni. Le seul changement est l'ajout du bloc `crons` :

```json
{
  "crons": [
    {
      "path": "/api/cron/generate-prep-list",
      "schedule": "0 9 * * *"
    }
  ],
  "headers": [ ... existant ... ]
}
```

**Pourquoi `0 9 * * *` ?**
Vercel Cron utilise **UTC**. 09:00 UTC = 04:00 EST (hiver) / 05:00 EDT (été).
Pour Le Nikoli à Québec, ça veut dire que la prep list sera générée entre 4h et 5h du matin, bien avant qu'Olivier arrive.

---

## Étape 2 — Mettre à jour la route cron

Remplace le fichier :
```
src/app/api/cron/generate-prep-list/route.ts
```

La nouvelle version :
- Lit les `prep_settings` de chaque restaurant (service_periods, safety_buffer, lookback_weeks)
- Supporte les restaurants avec lunch seul, dinner seul, ou les deux
- Fallback sur `restaurant_settings.module_smart_prep` si `prep_settings` n'existe pas encore
- Meilleur logging avec le nom du restaurant dans les résultats
- `maxDuration = 60` pour supporter plusieurs restaurants

---

## Étape 3 — Ajouter la variable `CRON_SECRET` sur Vercel

### Via le Dashboard Vercel (recommandé) :

1. Va sur **https://vercel.com/nassim-saighis-projects/rive/settings/environment-variables**
2. Clique **"Add New"**
3. Remplis :
   - **Key** : `CRON_SECRET`
   - **Value** : génère une valeur aléatoire sécurisée (voir ci-dessous)
   - **Environments** : coche ✅ Production, ✅ Preview, ✅ Development
4. Clique **"Save"**

### Générer une valeur sécurisée :

Option A — Dans ton terminal :
```bash
openssl rand -hex 32
```

Option B — Utilise cette valeur pré-générée :
```
sp_cron_a7f3e9b2c1d4e5f68097a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8091234
```

### Vérifier les variables existantes :

Assure-toi que ces variables sont aussi présentes (elles devraient l'être déjà) :
- `NEXT_PUBLIC_SUPABASE_URL` — URL de ton projet Supabase
- `SUPABASE_SERVICE_ROLE_KEY` — Clé service_role (nécessaire pour le cron qui bypass RLS)
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` — Clé anon publique

⚠️ **Important** : `SUPABASE_SERVICE_ROLE_KEY` ne doit JAMAIS avoir le préfixe `NEXT_PUBLIC_` 
car elle ne doit jamais être exposée côté client.

---

## Étape 4 — Commit & Push

```bash
git add vercel.json src/app/api/cron/generate-prep-list/route.ts
git commit -m "feat(smart-prep): configure Vercel Cron for nightly prep list generation

- Add cron job at 09:00 UTC (04:00-05:00 AM Eastern) for /api/cron/generate-prep-list
- Improve cron route to read per-restaurant prep_settings (service_periods, safety_buffer)
- Add fallback to restaurant_settings.module_smart_prep for legacy support
- Set maxDuration=60 for multi-restaurant batch processing

Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"

git push origin main
```

Vercel déploiera automatiquement et activera le cron.

---

## Étape 5 — Vérifier que le cron est actif

1. Après le déploiement, va sur **https://vercel.com/nassim-saighis-projects/rive/settings/crons**
2. Tu devrais voir :
   ```
   /api/cron/generate-prep-list    0 9 * * *    Every day at 9:00 AM (UTC)
   ```
3. Tu peux cliquer **"Trigger"** pour lancer une exécution manuelle de test

---

## Étape 6 — Test manuel (optionnel mais recommandé)

Tu peux tester l'API directement sans attendre le cron :

```bash
# Test via curl (remplace <TOKEN> par ton Supabase access token)
curl -H "Authorization: Bearer <TOKEN>" \
  "https://rivehub.com/api/prep-list?date=2026-02-28&service=lunch"
```

Ou depuis le dashboard Rive, navigue vers `/dashboard/prep-list`.

---

## Architecture finale

```
09:00 UTC (chaque nuit)
    │
    ▼
Vercel Cron → GET /api/cron/generate-prep-list
    │           (vérifie CRON_SECRET)
    │
    ▼
Supabase Admin → SELECT prep_settings WHERE enabled = true
    │
    ▼
Pour chaque restaurant:
    ├─ Lit les service_periods (lunch / dinner / all_day)
    ├─ Vérifie si une prep list existe déjà
    ├─ Appelle generatePrepList() depuis prep-engine.ts
    │     ├─ Étape 1: Couverts réservés
    │     ├─ Étape 2: Walk-in ratio → couverts totaux
    │     ├─ Étape 3: Mix produit POS → portions/item
    │     ├─ Étape 4: Recettes → ingrédients bruts
    │     ├─ Étape 5: BCG → priorisation
    │     ├─ Étape 6: Alertes (diététiques, anomalies)
    │     └─ Étape 7: Feedback loop (confidence_modifier)
    │
    ▼
INSERT prep_lists + prep_list_items + prep_list_ingredients
    │
    ▼
Le chef arrive le matin → sa prep list est prête 📋✅
```

---

## Limites Vercel Cron (plan gratuit)

- **Plan Hobby** : 2 cron jobs max, exécution 1x/jour minimum
- **Plan Pro** : 40 cron jobs, fréquence jusqu'à 1x/minute
- Le schedule `0 9 * * *` = 1x/jour, compatible avec tous les plans
