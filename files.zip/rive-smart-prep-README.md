# Smart Prep List — Audit Implementation Guide

> Maps every finding from `rive-ux-audit.md` to concrete code across 12 deliverable files.

---

## File Inventory

```
rive-fixes/
├── migrations/
│   └── migration_v16_prep_list_audit_fixes.sql   # 484 lines — DB schema + indexes + RLS
├── lib/
│   └── prep-engine.ts                            # 1160 lines — prediction engine core
├── api/
│   ├── prep-list/
│   │   ├── route.ts                              # 342 lines — GET/POST main endpoint
│   │   ├── feedback/route.ts                     # 123 lines — POS auto-fill + PATCH feedback
│   │   ├── history/route.ts                      # 107 lines — paginated history
│   │   └── analytics/route.ts                    # 313 lines — waste/ROI/accuracy aggregates
│   └── cron/
│       └── generate-prep-list/route.ts           # 274 lines — timezone-aware nightly cron
├── components/prep-list/
│   ├── PrepListDashboard.tsx                     # Main dashboard (sticky header, dual-view, etc.)
│   ├── PrepListAlerts.tsx                        # Three-tier alert hierarchy
│   ├── PrepListFeedback.tsx                      # POS auto-reconciliation + steppers
│   ├── PrepListOnboarding.tsx                    # Empty state + level progression
│   ├── PrepListPrint.tsx                         # Kitchen-friendly print layout
│   └── index.ts                                  # Barrel export
```

---

## Audit Finding → Implementation Map

### §1 — Critical Backend Issues

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 1.1 | Timezone-aware cron | `cron/generate-prep-list/route.ts` | Runs every 30min, checks each restaurant's `prep_generation_tz` + `prep_generation_hour` against local time |
| 1.2 | Cold start walk-in ratio | `lib/prep-engine.ts` → `getWalkInRatio()` | Industry defaults by restaurant type (fine-dining 12%, casual 35%, fast-casual 55%) + data maturity indicator |
| 1.3 | Confidence modifier drift | `lib/prep-engine.ts` → `applyConfidenceDecay()` | Exponential decay toward 1.0 after 14 days no feedback; auto-reset on recipe changes |
| 1.4 | Missing indexes | `migration_v16...sql` | Composite indexes on (restaurant_id, target_date, service_period), (prep_list_id, priority_score DESC), (restaurant_id, day_of_week, sale_date) |
| 1.5 | POS sync reliability | `lib/prep-engine.ts` → `checkDataFreshness()` | `last_pos_sync_at` check, degrade to Level 1 if >48hrs stale, surface warning badge |
| 1.6 | Multi-service aggregation | `api/prep-list/route.ts` | Supports `service=all_day\|lunch\|dinner`, aggregates ingredients across services |
| 1.7 | API pagination | `api/prep-list/history/route.ts` | `?from=&to=&page=&per_page=` + separate `/analytics` endpoint for aggregates |

### §2 — Chef-Facing UX (Make or Break)

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 2.1 | Morning speed: auto-load, print, push | `PrepListDashboard.tsx` | Auto-fetches today on mount, no clicks needed. `PrepListPrint.tsx` for kitchen print. Sticky header with cover count on scroll |
| 2.2 | Feedback loop (adoption risk) | `PrepListFeedback.tsx` + `api/feedback/route.ts` | POS auto-reconciliation pre-fills actuals, "All correct" bulk button, +/- steppers with 48px touch targets |
| 2.3 | Three-tier alert hierarchy | `PrepListAlerts.tsx` | 🔴 Critical (allergens, stock) non-dismissable, 🟡 Important (dietary), 🔵 Informational (occasions) collapsible |
| 2.4 | Confidence labels not numbers | `PrepListDashboard.tsx` → `getConfidenceLabel()` | Contextual: "Based on 8 weeks" (high), "Limited data — 2 weeks" (medium), "First prediction" (low) |
| 2.5 | Station grouping | `PrepListDashboard.tsx` | Toggle "Group by priority" / "Group by station" with configurable station assignments |
| 2.6 | Dual-view: items vs ingredients | `PrepListDashboard.tsx` | Equal-status tabs: 🍽️ "What to serve" and 🥕 "What to prep" |

### §3 — Manager/Owner Experience

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 3.1 | Cost dashboard & trends | `api/analytics/route.ts` | Weekly/monthly projections, predicted vs actual cost variance |
| 3.2 | Waste tracking | `api/analytics/route.ts` + `PrepListFeedback.tsx` | Calculates surplus × food_cost_per_portion, surfaces "waste avoided this month" |
| 3.3 | Team permissions | `migration_v16...sql` | RLS policies: viewer (any staff), editor (sous-chef+), admin (head chef/manager) |

### §4 — Onboarding & Progressive Disclosure

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 4.1 | Empty state experience | `PrepListOnboarding.tsx` | Module checklist with "Connect →" CTAs, level progress bar, benefit descriptions |
| 4.2 | Level transition communication | `PrepListOnboarding.tsx` | Visual level 1→2→3 progression, "what each level unlocks" explainer |
| 4.3 | Trust building timeline | `PrepListDashboard.tsx` | Accuracy tracking badge: shows trend over time, language evolves with data maturity |

### §5 — Cross-Module Integration

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 5.1 | Reservation note parsing confidence | `PrepListAlerts.tsx` | Shows "Probable — à vérifier" for medium-confidence AI extractions |
| 5.2 | BCG snapshot at generation | `lib/prep-engine.ts` | BCG categories snapshotted at generation time, not live-linked |
| 5.3 | Logbook event multipliers | `lib/prep-engine.ts` → `applyLogbookMultipliers()` | Tags: #event +20%, #rain -10%, #holiday +30% with learning |
| 5.4 | Inventory cross-reference | `lib/prep-engine.ts` → `crossReferenceInventory()` + `PrepListDashboard.tsx` | "Need 2.4kg → 1.8kg in stock → Order 0.6kg" shown inline in ingredients view |

### §6 — UI/Visual Design

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 6.1 | Touch targets + font sizes | All components | 48px minimum touch targets, 14-15px body text, responsive Tailwind |
| 6.2 | Priority color semantics | `PrepListDashboard.tsx` | Blue (high), amber (medium), gray (low) — avoids red/green. Action labels: "Préparer en premier" |
| 6.3 | Currency localization | `PrepListDashboard.tsx` | `Intl.NumberFormat` with restaurant locale + currency code |

### §7 — Technical Debt

| # | Finding | File(s) | How |
|---|---------|---------|-----|
| 7.1 | Claude AI fallback | `lib/prep-engine.ts` → `extractDietaryAlerts()` | Regex fallback for common keywords when AI unavailable; cached results |
| 7.2 | Regeneration versioning | `api/prep-list/route.ts` POST | Preserves old version, warns before overwrite of confirmed/noted lists |
| 7.3 | Offline capability | `PrepListPrint.tsx` | Print/PDF for immediate offline use (full service worker is deferred) |

---

## Migration Order

1. Run `migration_v16_prep_list_audit_fixes.sql`
2. Deploy `lib/prep-engine.ts`
3. Deploy API routes (all 5)
4. Deploy frontend components
5. Configure per-restaurant: `prep_generation_tz`, `prep_generation_hour`, `restaurant_type`
6. Set up Vercel Cron: `*/30 * * * *` → `/api/cron/generate-prep-list`

---

## Key Design Decisions

**Feedback is the #1 adoption risk.** The entire learning system dies if chefs don't submit feedback. That's why:
- POS auto-reconciliation pre-fills 80%+ of actuals automatically
- "All correct" confirms everything in one tap
- +/- steppers mean zero keyboard input needed
- Target: <60 seconds for a typical 15-item menu

**Levels are about data maturity, not paywalls.** A restaurant with only reservations gets a useful Level 1 immediately. Each additional module connection upgrades the experience visibly, creating natural incentive to adopt more of Rive.

**Inventory cross-reference is the biggest differentiator.** Going from "what to prep" to "what to order" in a single view is something no competitor does well. Prioritize this for Q2.
