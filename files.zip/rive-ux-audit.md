# Rive — Extensive UX/UI Audit
## Smart Prep List & Cross-Platform Experience

**Audit Date:** February 27, 2026  
**Scope:** Backend architecture, client-facing experience, Smart Prep List feature, and cross-module integration  
**Auditor:** Claude — Anthropic

---

## Executive Summary

Rive's Smart Prep List is an ambitious and well-architected feature that solves a genuine daily pain point for chefs. The concept document reveals strong systems thinking — the three-level degradation model, the feedback loop, and the cross-module data aggregation are all architecturally sound. However, the audit surfaces several critical UX gaps, backend concerns, and missed opportunities that could significantly impact adoption, trust, and daily usability in a high-pressure kitchen environment.

The findings are organized into five domains: **Backend & Data Architecture**, **Chef-Facing UX (the primary user)**, **Manager/Owner Experience**, **Onboarding & Progressive Disclosure**, and **Cross-Module Integration Coherence**.

---

## 1. Backend & Data Architecture

### 1.1 — Walk-In Ratio: Cold Start Problem

**Issue:** The walk-in ratio calculation relies on 8 weeks of historical data (`walk_in_ratio = (couverts_réels - couverts_réservés) / couverts_réels`). For new restaurants or newly onboarded ones, there's no data to compute this. The system defaults to... nothing explicit in the spec.

**Impact:** Level 1 predictions (reservations only) become unreliable without a sensible default. A restaurant with 40 reservations and no walk-in data could either overprepare massively or underprepare dangerously.

**Recommendation:**
- Provide configurable industry-standard defaults by restaurant type (fine dining: 10-15% walk-ins, casual: 25-40%, fast-casual: 50-70%). Let the chef set this during onboarding.
- Surface a prominent "data maturity" indicator in the UI: "Walk-in ratio based on 3 weeks of data — improving" vs. "Based on 8+ weeks — stable."
- Consider weighting more recent weeks more heavily (exponential decay) rather than flat 8-week average, since restaurant traffic patterns shift seasonally.

### 1.2 — Cron Job Timing: 4 AM Is Not Universal

**Issue:** The nightly cron at 4 AM assumes a single timezone. Restaurants in different timezones (Libro for Canada, Resy for US, Zenchef for France/Europe) need localized execution.

**Impact:** A restaurant in Vancouver could get their list generated at 1 AM Pacific (4 AM Eastern), missing late reservations. A Paris restaurant would get theirs at 10 AM local time — useless.

**Recommendation:**
- Store a `prep_generation_time` per restaurant (default: 4 AM local).
- Run the cron more frequently (every 30 min) but only generate for restaurants whose local time matches their configured generation hour.
- Add a "Last generated: 4:02 AM" timestamp in the UI so the chef knows the data freshness.
- Consider a "regenerate now" button that's prominently placed — the chef might get a flurry of late reservations after the cron runs.

### 1.3 — Confidence Modifier Drift Protection

**Issue:** The `confidence_modifier` is clamped between 0.5 and 2.0, which is good. But the feedback mechanism doesn't account for systemic shifts (menu change, new chef, seasonal transition). A modifier that slowly drifted to 1.8 over winter for a soup item shouldn't persist into summer.

**Impact:** Stale modifiers could cause persistent over- or under-prediction for months after a regime change.

**Recommendation:**
- Implement automatic modifier decay: slowly pull modifiers back toward 1.0 when no feedback is received for 2+ weeks on an item.
- When a menu item is significantly modified (recipe change, price change), offer to reset its confidence_modifier.
- Add a "Reset predictions" action in settings that clears all modifiers — useful when a restaurant changes seasons or chefs.

### 1.4 — Missing: Multi-Service Day Handling

**Issue:** The schema supports `'lunch' | 'dinner' | 'all_day'` but the algorithm description doesn't address how ingredients are aggregated across services. If the risotto is predicted for both lunch (8 portions) and dinner (12 portions), does the ingredients list show 20 portions aggregated, or two separate lists?

**Impact:** This is a fundamental workflow question. Most chefs prep once in the morning for both services. Two separate lists would be confusing; one combined list might miss the fact that some items are lunch-only.

**Recommendation:**
- Default to a combined "full day" view with service-period badges per item.
- Allow toggling between "All Day | Lunch Only | Dinner Only" views.
- In the ingredients panel, always show the full-day aggregate (since you prep once) but indicate which service drives each ingredient.

### 1.5 — POS Data Freshness & Sync Reliability

**Issue:** POS integration is described as "Sync CSV ou API" — but the concept doesn't address what happens when POS data is stale (last sync was 3 days ago) or when the sync fails.

**Impact:** The item mix calculation depends on historical POS data. If the most recent sync failed, the system might use outdated sales patterns without the chef knowing.

**Recommendation:**
- Add a `last_pos_sync_at` field and display it in the prep list header.
- If POS data is >48 hours stale, degrade gracefully to Level 1 with a warning: "POS data is outdated — predictions based on reservations only."
- Log sync failures to the alerts system so the chef (or manager) is notified.

### 1.6 — Database: Missing Indexes for Performance

**Issue:** The schema tables are defined but no indexes are specified. Given the queries required (reservations by date + restaurant, POS sales by day_of_week + restaurant + date range, prep_lists by target_date + restaurant), query performance will degrade as data grows.

**Recommendation:**
Add composite indexes for the critical query paths:
- `prep_lists`: `(restaurant_id, target_date, service_period)` — the primary lookup.
- `prep_list_items`: `(prep_list_id, priority_score DESC)` — for sorted display.
- `pos_sales`: `(restaurant_id, day_of_week, sale_date)` — for the 8-week mix calculation.
- `reservations`: `(restaurant_id, reservation_date, status)` — for cover counting.

### 1.7 — API Design: Missing Pagination & Filtering on History

**Issue:** The `/api/prep-list/history` route returns past prep lists with accuracy metrics, but there's no pagination, date range filtering, or item-specific filtering described.

**Impact:** After 6 months of daily prep lists (180+ records with items), this endpoint will return massive payloads. A chef wanting to see "how accurate was my risotto prediction last month" can't query efficiently.

**Recommendation:**
- Add query params: `?from=2026-01-01&to=2026-01-31&item=risotto&page=1&limit=20`
- Return pagination metadata: `{ data: [...], total: 45, page: 1, hasMore: true }`
- Consider a separate `/api/prep-list/analytics` endpoint for aggregate metrics (average accuracy by item, trending items, waste estimation over time).

---

## 2. Chef-Facing UX (Primary User)

### 2.1 — The Morning Workflow: Speed Is Everything

**Critical Insight:** A chef arriving at 7 AM doesn't have time to navigate dashboards. They need their list in under 5 seconds — ideally one tap from the home screen.

**Current Gap:** The concept shows a full dashboard UI with tabs, sections, and detailed information. This is great for initial exploration but hostile to daily use.

**Recommendations:**
- **Quick-access landing:** When the chef opens the app, the prep list for today should auto-load without any clicks. Don't make them select a date or service — default to "next upcoming service."
- **Print / PDF export:** Add a one-tap "Print" button that generates a clean, printer-friendly version. Many kitchens still pin a paper list to the wall. This is a trivial feature with enormous adoption impact.
- **Push notification:** "Your prep list for tonight is ready — 54 covers, 3 gluten-free alerts" sent at the configured generation time. One tap opens directly to the list.
- **Persistent sticky header:** As the chef scrolls through items, keep the cover count and key alerts visible at all times.

### 2.2 — Feedback UI: "30 Seconds" Is Optimistic

**Issue:** The feedback mockup claims "Durée: 30 secondes" but shows individual item-by-item adjustment. With 6+ items across a busy restaurant's full menu (realistically 15-25 items), this becomes a 3-5 minute task that gets skipped.

**Impact:** Without feedback, the learning loop breaks down entirely. This is the single biggest UX risk in the entire system.

**Recommendations:**
- **Bulk "all correct" button:** If most predictions were good, let the chef tap "All correct ✓" and only adjust the outliers. Pre-fill everything as "matched prediction."
- **Quick +/- steppers:** Instead of typing numbers, show `[-] 12 [+]` steppers. Tap once for each portion off. Much faster than keyboard input.
- **POS auto-reconciliation:** If POS data is connected, the actual portions sold are already known. Auto-fill the feedback from POS sales data and just ask the chef to confirm. This makes feedback nearly zero-effort.
- **Skip without guilt:** If the chef doesn't fill feedback, don't nag. Surface a gentle monthly summary: "You've given feedback 18 of 30 days — your predictions are 12% more accurate on days you do."
- **End-of-service prompt:** Trigger the feedback UI automatically when the POS registers the last transaction or when the chef closes the logbook for the day.

### 2.3 — Alert Hierarchy: Not All Alerts Are Equal

**Issue:** The mockup shows dietary alerts and anniversary alerts at the same visual level (both are colored boxes at the top). But "3 gluten-free reservations" is operationally critical (prep failure risk), while "1 anniversary" is a nice-to-know.

**Recommendations:**
- Implement a three-tier alert system:
  - 🔴 **Critical** (red): Allergens, low stock alerts, unusual volume spikes. These require action.
  - 🟡 **Important** (amber): Dietary preferences (gluten-free, vegan). These need preparation.
  - 🔵 **Informational** (blue): Occasions, VIP notes. Nice to know but no action required.
- Allow chefs to dismiss informational alerts and configure which categories are critical for their kitchen.

### 2.4 — Confidence Score: Meaningless Without Context

**Issue:** The mockup shows "Confiance 92%" next to items. A chef has no frame of reference for whether 92% is good or bad, or what it means practically.

**Impact:** Displaying raw confidence scores can erode trust if the chef doesn't understand them, or be ignored entirely as noise.

**Recommendations:**
- Replace numeric confidence with contextual labels: "Based on 8 weeks of sales data" (high confidence), "Limited data — 2 weeks" (medium), "First prediction — no historical data" (low).
- Use subtle visual cues instead of numbers: a solid bar = high confidence, a dashed/dotted bar = lower confidence. Less cognitive load.
- Reserve the numeric score for the analytics/history view where managers care about precision metrics.

### 2.5 — Missing: Station-Based Grouping

**Issue:** The prep list organizes items by priority (BCG matrix). But in a real kitchen, prep is organized by station: garde-manger (cold), saucier (hot), pâtissier (desserts), etc.

**Impact:** A chef reading the list by priority has to mentally reorganize it by station assignment. This friction reduces the list's usefulness.

**Recommendation:**
- Add an optional "Group by station" toggle that organizes items by kitchen station.
- Let the restaurant configure which menu items belong to which station (a one-time setup).
- Default to "Group by priority" but remember the chef's preference.

### 2.6 — Missing: Prep Task vs. Menu Item Distinction

**Issue:** The current model maps 1:1 between menu items and prep tasks. But in reality, many prep tasks are shared across items (making stock, blanching vegetables, preparing sauce bases) and happen at different times.

**Impact:** A chef doesn't prep "12 risottos" — they prep "2.4kg arborio rice, pre-soak," "960g mushrooms, cleaned and sliced," "3L stock, heated." The ingredient list partially addresses this, but it's in a separate panel.

**Recommendation:**
- Consider a dual-view: "What to serve" (menu items + portions) and "What to prep" (ingredient tasks organized by prep method and timing). The ingredient panel is already close to this — promote it to equal status with the item list rather than a secondary panel.
- Add estimated prep time per task if recipe data includes it. This helps the chef plan their morning.

---

## 3. Manager/Owner Experience

### 3.1 — Missing: Cost Projection Dashboard

**Issue:** The system estimates food cost per prep list ($187.40 in the mockup) but there's no visibility into cost trends over time, comparison to actual food costs, or budget tracking.

**Recommendation:**
- Add a weekly/monthly cost projection view: "Estimated food cost this week: $1,240 | Last week actual: $1,180 | Variance: +5%."
- Connect to the food cost module to show predicted vs. actual cost accuracy.
- Flag days where predicted food cost exceeds a configurable threshold.

### 3.2 — Missing: Waste Tracking Integration

**Issue:** The system claims 15-25% waste reduction as a value prop, but there's no mechanism to actually measure waste. The feedback loop captures "surplus portions" but doesn't translate this into dollar waste or weight waste.

**Recommendation:**
- Calculate estimated waste per feedback: `surplus_portions × food_cost_per_portion`.
- Surface a running "waste avoided" metric: "This month, Smart Prep saved an estimated $420 in food waste."
- This becomes a powerful retention and marketing metric — tangible ROI.

### 3.3 — Missing: Team Permissions

**Issue:** No role-based access is described. Can a line cook view the prep list? Can a sous-chef submit feedback? Can only the head chef regenerate predictions?

**Recommendation:**
- **Viewer:** Can see the prep list and ingredients (any kitchen staff).
- **Editor:** Can submit feedback and add chef notes (sous-chef and above).
- **Admin:** Can configure safety buffer, reset modifiers, access analytics (head chef, manager).

---

## 4. Onboarding & Progressive Disclosure

### 4.1 — The Empty State Problem

**Issue:** When a restaurant first enables Smart Prep List, every data source is empty. The current concept doesn't describe what the chef sees on Day 1.

**Impact:** A blank or unhelpful first experience kills feature adoption immediately.

**Recommendation:**
- **Day 1 with reservations only:** Show a simple cover forecast with prominent "Connect your POS to unlock portion predictions" CTA. Make Level 1 feel valuable on its own, not like a degraded experience.
- **Guided setup wizard:** "Smart Prep works best with more data. You have ✅ Reservations, ❌ POS Sales, ❌ Recipes. Connect POS to improve predictions by 40%." Progressive checkboxes that celebrate each connection.
- **Sample data preview:** Before the first real prediction, show a mock prep list using demo data to illustrate what the full experience looks like. "Here's what your prep list will look like once we have 2 weeks of sales data."

### 4.2 — Level Transition Communication

**Issue:** When a restaurant graduates from Level 1 to Level 2 (POS connected) or Level 2 to Level 3 (recipes added), there's no described communication of this improvement.

**Recommendation:**
- Trigger a celebratory notification: "🎉 Smart Prep upgraded to Level 2! You can now see predicted portions per menu item."
- Show a before/after comparison: "Before: 54 covers estimated. Now: 54 covers → 12 risottos, 10 saumons, 8 tartares."
- Add a small "Level 3" badge on the prep list footer (already in the mockup — good) but make it tappable to explain what each level means.

### 4.3 — Trust Building Over Time

**Issue:** Predictive systems face a trust deficit — chefs will ignore the list if early predictions are inaccurate. The concept doesn't describe how to build trust during the first critical weeks.

**Recommendation:**
- **Week 1-2:** Position as "suggestions" not "predictions." Use language like "Based on your reservations, here's a starting point for today's prep."
- **Week 3-4:** After receiving feedback, show improvement: "Your prep list accuracy improved from 68% to 79% this week."
- **Month 2+:** Graduate the language to confident predictions: "Today's prep list — 85% accuracy over the last 30 days."
- Never show overconfident language until the system has proven itself with data.

---

## 5. Cross-Module Integration Coherence

### 5.1 — Reservation Platform → Prep Engine: Note Parsing Reliability

**Issue:** Claude AI is used to extract dietary mentions from customer notes. But reservation notes are incredibly messy: "anniversary dinner, wife doesn't eat fish, bring cake at 9, table near window pls." The concept doesn't address parsing failure modes.

**Recommendation:**
- Classify AI-extracted alerts with confidence: "High confidence: gluten-free (explicit mention)" vs. "Possible: dairy-free (inferred from 'lactose intolerant')."
- Add a "Verify" action on each dietary alert so the chef can confirm or dismiss.
- Track AI parsing accuracy over time. If it's consistently wrong (extracting "fish" as an allergen from "fish dish request"), feed corrections back.

### 5.2 — Menu Engineering BCG ↔ Prep Priority: Potential Conflict

**Issue:** BCG categorization is relatively static (updated monthly or quarterly from menu engineering analysis), but the prep list is generated daily. An item could be reclassified from "Phare" to "Dérive" mid-week, causing confusing priority shifts.

**Recommendation:**
- Use a snapshot of the BCG category at prep list generation time (already partially done with `bcg_category` in `prep_list_items`).
- If BCG categories change, surface it as an alert: "Risotto reclassified from Phare to Ancre based on this month's sales analysis. Priority adjusted."
- Allow the chef to override priority per item per day: "I know risotto is trending down, but I have a VIP group requesting it tonight — keep it high priority."

### 5.3 — Logbook/Notes Integration: Underspecified

**Issue:** The concept mentions "events logged in the journal (match ce soir, fête de quartier, météo)" as a data source, but the algorithm doesn't describe how logbook entries mechanically affect predictions.

**Recommendation:**
- Define specific logbook tags that trigger multipliers: `#event +20%`, `#rain -10%`, `#holiday +30%`. Let the chef create custom tags with associated impact.
- When the chef creates a logbook entry with a tag, show the impact preview: "Adding #hockey-game will increase tonight's cover estimate from 54 to 65 (+20%)."
- Over time, learn the actual impact of these events: "Last 3 hockey game nights averaged +18% covers vs. your +20% tag."

### 5.4 — Missing: Inventory/Stock Cross-Reference

**Issue:** The ingredients panel shows what's needed (2.4kg riz arborio) but doesn't check current stock levels. The concept mentions inventory briefly ("En rupture de riz arborio selon le dernier inventaire") but it's not part of the data flow.

**Recommendation:**
- If inventory data exists, subtract current stock from predicted needs: "Need 2.4kg arborio → 1.8kg in stock → **Order 0.6kg**."
- Highlight items where predicted need exceeds current stock as shopping alerts.
- This is a massive differentiator — going from "what to prep" to "what to order" is the natural next step.

---

## 6. UI/Visual Design Observations

### 6.1 — Concept Document Design (the HTML spec itself)

The concept document is well-crafted as an internal spec with clear visual hierarchy. A few observations:

- **Dark theme for a kitchen tool spec:** Ironic that the spec document uses a dark theme while the actual prep list mockup uses light. The production app should support both — chefs in bright kitchens need a high-contrast light theme; chefs reviewing prep at home the night before may prefer dark.
- **The mockup is desktop-oriented:** Kitchen tablets are the primary device. The mockup at 540px max-width is close to tablet size, but the information density may be too high for wet/greasy fingers on a screen. Consider larger touch targets (minimum 48px tap areas).
- **Light theme in the mockup uses good contrast** — the blue-on-white header, clear priority color coding, and readable typography are solid. But the 11px and 12px font sizes are too small for kitchen use. Minimum 14px for body text in the production app.

### 6.2 — Color Coding Consistency

**Issue:** The priority colors in the mockup (red = high, amber = medium, green = low) create a counterintuitive mapping. In most contexts, red = danger/bad and green = good. Here, red means "prepare this first" (a positive priority), which could confuse new users.

**Recommendation:**
- Consider using blue/purple for high priority (the brand accent), amber for medium, and gray for low. This avoids the stop-light metaphor entirely.
- Or relabel: instead of "Priorité haute/moyenne/basse," use "Préparer en premier / Préparer ensuite / Quantité minimale." Action-oriented labels over abstract priority.

### 6.3 — Currency Display

**Issue:** The mockup uses `$` for food cost estimates, but Rive serves Canadian (CAD), American (USD), and French (EUR) restaurants. No currency code is shown.

**Recommendation:**
- Always display with currency code: "$187.40 CAD" or "187,40 €". 
- Respect locale formatting (comma vs. period as decimal separator for European markets).

---

## 7. Technical Debt & Scalability Concerns

### 7.1 — Claude AI Dependency for Alerts

Using Claude to parse reservation notes is clever but introduces an external dependency in a nightly batch job. If the API is down or rate-limited during the cron run, dietary alerts are missed entirely.

**Recommendation:**
- Implement a regex-based fallback for common dietary keywords (gluten, vegan, végétarien, allergi*, etc.) that runs locally. Use Claude as an enhancement layer, not a dependency.
- Cache AI results: once a note has been parsed, store the extracted alerts so re-runs don't re-call the API.

### 7.2 — Prep List Regeneration Semantics

**Issue:** The API supports both GET (auto-generate if missing) and POST (force regenerate). But what happens to the chef's manual notes and feedback if the list is regenerated? Are they preserved or wiped?

**Recommendation:**
- POST regeneration should create a new version while preserving the old one.
- Warn before regeneration: "This will create a new prediction. Your notes from the current list will be moved to history."
- Never silently overwrite feedback data.

### 7.3 — Offline Capability

**Issue:** No offline support is described. Kitchen environments often have spotty wifi.

**Recommendation:**
- Cache the current day's prep list locally (service worker or local storage).
- The list should be fully usable offline once loaded.
- Queue feedback submissions for sync when connectivity returns.

---

## Summary of Priority Actions

**Immediate (Pre-Launch):**
1. Solve the cold start / empty state experience
2. Add print/PDF export for the prep list
3. Implement POS auto-reconciliation for near-zero-effort feedback
4. Add "All correct" bulk feedback button
5. Fix timezone-aware cron scheduling
6. Add database indexes for critical query paths

**Short-Term (First 30 Days):**
7. Station-based grouping toggle
8. Three-tier alert hierarchy (critical / important / informational)
9. Replace numeric confidence with contextual labels
10. Implement push notifications for list readiness
11. Add waste tracking / ROI metrics for managers

**Medium-Term (Quarter 2):**
12. Inventory cross-reference ("need vs. have")
13. Logbook event multipliers with learning
14. Multi-service day combined view
15. Offline caching with service worker
16. Chef permission tiers

---

*This audit is based on the concept document and architecture specification. A live product audit with real user observation in kitchen environments would further refine these recommendations.*
